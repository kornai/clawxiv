#!/usr/bin/env bash
# clawxiv_publish_v2.sh — master publication script for ClawXiv v2
#
# Automates steps 2-12 of the v2 publication sequence.
# Steps 1 (editorial), 13 (lebadus.ai upload), and 14 (arXiv) remain manual.
#
# Usage:
#   ./clawxiv_publish_v2.sh [--skip-compile] [--skip-ipfs] [--skip-github] [--dry-run]
#
# --skip-compile  Use existing PDF, do not run pdflatex
# --skip-ipfs     Skip IPFS pinning and IPNS update
# --skip-github   Skip git commit and push
# --dry-run       Print what would be done, execute nothing destructive
#
# Environment variables (override defaults):
#   AK_EMAIL        GPG email for A. Kornai     (default: andras@kornai.com)
#   AI_EMAIL        GPG email for AI contributor (default: claude-sonnet-4-6@clawxiv.operator.kornai.com)
#   IPNS_KEY        IPFS key name                (default: clawxiv)
#   GITHUB_REPO     GitHub repo slug             (default: kornai/clawxiv)
#   BUNDLE_VERSION  Version tag for log/manifest (default: v2)
#   CONVERSATION_URL  Attestation conversation URL
#
# Prerequisites:
#   gpg, python3, pdflatex (unless --skip-compile),
#   ipfs/Kubo daemon (unless --skip-ipfs),
#   git with push access (unless --skip-github)
#
# IMPORTANT: This script does NOT regenerate appendix_a.tex from prompts.jsonl.
# Edit appendix_a.tex manually before running, or run gen_appendix_a.py
# separately. The existing appendix_a.tex is used as-is.

set -euo pipefail

# -----------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

TEX_FILE="clawxiv_whitepaper_v2.tex"
PDF_FILE="clawxiv_whitepaper_v2.pdf"
BUNDLE_VERSION="${BUNDLE_VERSION:-v2}"
AK_EMAIL="${AK_EMAIL:-andras@kornai.com}"
AI_EMAIL="${AI_EMAIL:-claude-sonnet-4-6@clawxiv.operator.kornai.com}"
IPNS_KEY="${IPNS_KEY:-clawxiv}"
GITHUB_REPO="${GITHUB_REPO:-kornai/clawxiv}"
CONVERSATION_URL="${CONVERSATION_URL:-https://claude.ai/share/3378b2a0-16b0-494e-b603-bffbef5e1ce5}"

KEYS_DIR="${SCRIPT_DIR}/keys"
BUNDLE_SRC_DIR="${SCRIPT_DIR}/bundle_src"
OUT_DIR="${SCRIPT_DIR}/out"
MANIFEST_JSON="${SCRIPT_DIR}/manifest.json"
PROVENANCE_JSON="${BUNDLE_SRC_DIR}/provenance.json"
LOG_JSONL="${OUT_DIR}/clawxiv_log.jsonl"
BUNDLE_ZIP="${OUT_DIR}/paper_bundle.zip"
CLASS_JSON="${OUT_DIR}/classification.json"

SKIP_COMPILE=false
SKIP_IPFS=false
SKIP_GITHUB=false
DRY_RUN=false

for arg in "$@"; do
  case "$arg" in
    --skip-compile) SKIP_COMPILE=true ;;
    --skip-ipfs)    SKIP_IPFS=true ;;
    --skip-github)  SKIP_GITHUB=true ;;
    --dry-run)      DRY_RUN=true ;;
  esac
done

run() {
  # Execute a command, or print it if --dry-run
  if $DRY_RUN; then
    echo "  [dry-run] $*"
  else
    "$@"
  fi
}

# macOS sha256sum compatibility
SHA256="sha256sum"
if ! command -v sha256sum &>/dev/null && command -v shasum &>/dev/null; then
  SHA256="shasum -a 256"
fi

echo "======================================================="
echo " ClawXiv v2 master publication script"
echo " $(date)"
echo "======================================================="
echo ""

# -----------------------------------------------------------------------
# Step 2: Check prerequisites
# -----------------------------------------------------------------------
echo "[2/12] Checking prerequisites..."

MISSING=0
check_cmd() {
  if ! command -v "$1" &>/dev/null; then
    echo "  MISSING: $1 — $2"
    MISSING=1
  else
    echo "  OK: $1"
  fi
}

check_cmd gpg     "required for signing"
check_cmd python3 "required for bundling and manifest"
check_cmd git     "required unless --skip-github"
$SKIP_COMPILE || check_cmd pdflatex "required unless --skip-compile"
$SKIP_IPFS    || check_cmd ipfs     "required unless --skip-ipfs"

if [[ $MISSING -ne 0 ]]; then
  echo ""
  echo "ERROR: Missing prerequisites. Resolve above or use --skip-* flags."
  exit 1
fi

# Check Python venv / cryptography package
if ! python3 -c "from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey" 2>/dev/null; then
  echo ""
  echo "  WARNING: 'cryptography' Python package not found."
  echo "  Attempting to activate .venv if present..."
  if [[ -f "${SCRIPT_DIR}/.venv/bin/activate" ]]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/.venv/bin/activate"
    echo "  Activated .venv"
  else
    echo "  No .venv found. Run:"
    echo "    python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt"
    exit 1
  fi
fi

# Check source files exist
[[ -f "$TEX_FILE" ]] || { echo "ERROR: $TEX_FILE not found."; exit 1; }
[[ -f "appendix_a.tex" ]] || { echo "ERROR: appendix_a.tex not found. Create it manually or run gen_appendix_a.py."; exit 1; }
[[ -f "clawxiv.py" ]] || { echo "ERROR: clawxiv.py not found."; exit 1; }

mkdir -p "$KEYS_DIR" "$BUNDLE_SRC_DIR" "$OUT_DIR"

echo "  All prerequisites satisfied."

# -----------------------------------------------------------------------
# Step 3: Generate keys (idempotent — skip if already present)
# -----------------------------------------------------------------------
echo ""
echo "[3/12] Generating keys..."

# GPG AI contributor key (ai_keygen.sh is idempotent — checks keyring first)
if [[ -f "${KEYS_DIR}/claude_pubkey.asc" ]]; then
  echo "  AI GPG key already present: ${KEYS_DIR}/claude_pubkey.asc"
else
  echo "  Generating AI contributor GPG key..."
  run bash "${SCRIPT_DIR}/ai_keygen.sh"
fi

# Ed25519 PEM author key
if [[ -f "${KEYS_DIR}/author.priv.pem" && -f "${KEYS_DIR}/author.pub.pem" ]]; then
  echo "  Author PEM key already present."
else
  echo "  Generating author Ed25519 PEM key..."
  run python3 clawxiv.py keygen \
    --private-key "${KEYS_DIR}/author.priv.pem" \
    --public-key  "${KEYS_DIR}/author.pub.pem"
fi

# Ed25519 PEM classifier key
if [[ -f "${KEYS_DIR}/classifier.priv.pem" && -f "${KEYS_DIR}/classifier.pub.pem" ]]; then
  echo "  Classifier PEM key already present."
else
  echo "  Generating classifier Ed25519 PEM key..."
  run python3 clawxiv.py keygen \
    --private-key "${KEYS_DIR}/classifier.priv.pem" \
    --public-key  "${KEYS_DIR}/classifier.pub.pem"
fi

# Verify AK GPG key is in keyring
if ! gpg --list-keys "$AK_EMAIL" &>/dev/null; then
  echo ""
  echo "ERROR: GPG key for $AK_EMAIL not found in keyring."
  echo "Import it with: gpg --import your_key.asc"
  exit 1
fi
echo "  AK GPG key present: $AK_EMAIL"

# -----------------------------------------------------------------------
# Step 4: Compile LaTeX
# -----------------------------------------------------------------------
echo ""
if ! $SKIP_COMPILE; then
  echo "[4/12] Compiling LaTeX (2 passes)..."
  echo "  NOTE: Using existing appendix_a.tex (not regenerating from prompts.jsonl)"
  run pdflatex -interaction=nonstopmode "$TEX_FILE" > /tmp/clawxiv_latex1.log 2>&1
  echo "  Pass 1 done."
  run pdflatex -interaction=nonstopmode "$TEX_FILE" > /tmp/clawxiv_latex2.log 2>&1
  echo "  Pass 2 done. -> $PDF_FILE"
else
  echo "[4/12] Skipping LaTeX compilation (--skip-compile)."
  [[ -f "$PDF_FILE" ]] || { echo "ERROR: $PDF_FILE not found and --skip-compile set."; exit 1; }
  echo "  Using existing $PDF_FILE"
fi

# -----------------------------------------------------------------------
# Step 5: Assemble bundle_src/
# -----------------------------------------------------------------------
echo ""
echo "[5/12] Assembling bundle_src/..."

# Files to include in the signed bundle source tree.
# Private keys are explicitly excluded.
BUNDLE_FILES=(
  "$TEX_FILE"
  "$PDF_FILE"
  "appendix_a.tex"
  "clawxiv.py"
  "ai_keygen.sh"
  "gen_appendix_a.py"
  "log_prompt.sh"
  "publish_v2.sh"
  "clawxiv_publish_v2.sh"
  "requirements.txt"
)

for f in "${BUNDLE_FILES[@]}"; do
  if [[ -f "$f" ]]; then
    run cp "$f" "${BUNDLE_SRC_DIR}/"
    echo "  copied: $f"
  else
    echo "  WARNING: $f not found, skipping."
  fi
done

# Copy public keys only
for pk in "${KEYS_DIR}/claude_pubkey.asc" \
          "${KEYS_DIR}/claude_keyid.txt" \
          "${KEYS_DIR}/author.pub.pem" \
          "${KEYS_DIR}/classifier.pub.pem"; do
  if [[ -f "$pk" ]]; then
    run cp "$pk" "${BUNDLE_SRC_DIR}/"
    echo "  copied: $(basename $pk)"
  fi
done

# -----------------------------------------------------------------------
# Step 6: Write provenance.json
# -----------------------------------------------------------------------
echo ""
echo "[6/12] Writing provenance.json..."

# Get AI key fingerprint if available
AI_FINGERPRINT=""
if [[ -f "${KEYS_DIR}/claude_keyid.txt" ]]; then
  AI_FINGERPRINT=$(cat "${KEYS_DIR}/claude_keyid.txt")
fi

TIMESTAMP_NOW=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if ! $DRY_RUN; then
python3 - <<PYEOF
import json

provenance = {
    "schema_version": 1,
    "created_at": "${TIMESTAMP_NOW}",
    "bundle_version": "${BUNDLE_VERSION}",
    "ai_attestation": {
        "agent": "Claude Sonnet 4.6",
        "vendor": "Anthropic PBC",
        "conversation_url": "${CONVERSATION_URL}",
        "attestation": (
            "I, Claude Sonnet 4.6, have read and reviewed "
            "clawxiv_whitepaper_v2.tex and the accompanying tools "
            "(ai_keygen.sh, log_prompt.sh, gen_appendix_a.py, publish.sh, "
            "clawxiv.py) as delivered in this bundle. "
            "I find them safe, coherent, and consistent with their stated "
            "purposes. I approve them for inclusion in the v2 ClawXiv bundle."
        ),
        "attestation_date": "2026-03-11",
        "operator_key_email": "${AI_EMAIL}",
        "operator_key_fingerprint": "${AI_FINGERPRINT}",
    },
    "human_attestation": {
        "agent": "Andras Kornai",
        "email": "${AK_EMAIL}",
        "note": "Corresponding and responsible author. All final decisions by AK."
    },
    "conversation_share_url": "${CONVERSATION_URL}",
}

with open("${PROVENANCE_JSON}", "w") as f:
    json.dump(provenance, f, indent=2, ensure_ascii=False)
    f.write("\n")

print(f"  Written: ${PROVENANCE_JSON}")
PYEOF
else
  echo "  [dry-run] Would write ${PROVENANCE_JSON}"
fi

# -----------------------------------------------------------------------
# Step 7: Create clawxiv.py bundle
# -----------------------------------------------------------------------
echo ""
echo "[7/12] Creating signed bundle (clawxiv.py)..."

run python3 clawxiv.py bundle-create \
  --root-dir   "${BUNDLE_SRC_DIR}" \
  --out-bundle "${BUNDLE_ZIP}" \
  --private-key "${KEYS_DIR}/author.priv.pem" \
  --public-key  "${KEYS_DIR}/author.pub.pem" \
  --engine pdflatex

echo "  Bundle written: ${BUNDLE_ZIP}"

# -----------------------------------------------------------------------
# Step 8: Verify bundle
# -----------------------------------------------------------------------
echo ""
echo "[8/12] Verifying bundle..."

run python3 clawxiv.py bundle-verify --bundle "${BUNDLE_ZIP}"
echo "  Verification: OK"

# -----------------------------------------------------------------------
# Step 9: Bootstrap manifest.json for publish.sh
# -----------------------------------------------------------------------
# publish.sh expects a pre-existing manifest.json with a "files" array.
# We bootstrap it from the clawxiv.py bundle manifest, then publish.sh
# will update hashes and add GPG signatures.
echo ""
echo "[9/12] Bootstrapping manifest.json from bundle..."

if ! $DRY_RUN; then
python3 - <<PYEOF
import json, zipfile

with zipfile.ZipFile("${BUNDLE_ZIP}", "r") as zf:
    bundle_manifest = json.loads(zf.read("manifest.json").decode("utf-8"))

# Build the manifest.json that publish.sh expects
manifest = {
    "schema": "clawxiv-manifest-v1",
    "bundle_version": "${BUNDLE_VERSION}",
    "created_at": bundle_manifest["created_at"],
    "bundle_root": bundle_manifest["bundle_root"],
    "conversation_url": "${CONVERSATION_URL}",
    "files": [
        {"path": "${TEX_FILE}", "hash_sha256": ""},
        {"path": "${PDF_FILE}", "hash_sha256": ""},
    ],
    "authors": bundle_manifest.get("authors", []),
    "provenance": [
        {
            "type": "clawxiv_bundle",
            "bundle_zip": "out/paper_bundle.zip",
            "bundle_root": bundle_manifest["bundle_root"],
        },
        {
            "type": "ai_attestation",
            "conversation_url": "${CONVERSATION_URL}",
            "agent": "Claude Sonnet 4.6",
            "operator_key_email": "${AI_EMAIL}",
        }
    ],
}

with open("${MANIFEST_JSON}", "w") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)
    f.write("\n")

print(f"  manifest.json written with bundle_root: {bundle_manifest['bundle_root']}")
PYEOF
else
  echo "  [dry-run] Would write ${MANIFEST_JSON}"
fi

# -----------------------------------------------------------------------
# Step 10: Transparency log entry
# -----------------------------------------------------------------------
echo ""
echo "[10/12] Appending transparency log event..."

# Extract bundle_root for log payload
if ! $DRY_RUN; then
  BUNDLE_ROOT=$(python3 clawxiv.py manifest-show --bundle "${BUNDLE_ZIP}" \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['bundle_root'])")

  python3 clawxiv.py log-append \
    --log "${LOG_JSONL}" \
    --type publish \
    --payload-json "{\"bundle\":\"out/paper_bundle.zip\",\"bundle_root\":\"${BUNDLE_ROOT}\",\"version\":\"${BUNDLE_VERSION}\",\"conversation\":\"${CONVERSATION_URL}\"}" \
    --signer-priv "${KEYS_DIR}/author.priv.pem"
  echo "  Log entry appended: ${LOG_JSONL}"
else
  echo "  [dry-run] Would append to ${LOG_JSONL}"
fi

# -----------------------------------------------------------------------
# Step 11: Sign classification
# -----------------------------------------------------------------------
echo ""
echo "[11/12] Signing classification statement..."

if ! $DRY_RUN; then
  BUNDLE_ROOT=$(python3 clawxiv.py manifest-show --bundle "${BUNDLE_ZIP}" \
    | python3 -c "import sys,json; print(json.load(sys.stdin)['bundle_root'])")

  python3 clawxiv.py classify-sign \
    --bundle-root "$BUNDLE_ROOT" \
    --primary cs.CL \
    --secondary cs.AI \
    --classifier-priv "${KEYS_DIR}/classifier.priv.pem" \
    --classifier-pub  "${KEYS_DIR}/classifier.pub.pem" \
    --out "${CLASS_JSON}"

  python3 clawxiv.py classify-verify --signed-statement "${CLASS_JSON}"
  echo "  Classification signed and verified: ${CLASS_JSON}"
else
  echo "  [dry-run] Would sign and verify classification -> ${CLASS_JSON}"
fi

# -----------------------------------------------------------------------
# Step 12: GPG sign, IPFS pin, GitHub push
# -----------------------------------------------------------------------
echo ""
echo "[12/12] Signing, pinning, and pushing..."

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

echo "  Signing manifest.json with AK key..."
run gpg --armor --detach-sign \
    --pinentry-mode loopback \
    --local-user "$AK_EMAIL" \
    --output "${MANIFEST_JSON}.ak.sig" \
    "$MANIFEST_JSON"
echo "  Signed -> ${MANIFEST_JSON}.ak.sig"

echo "  Signing manifest.json with AI contributor key..."
run gpg --armor --detach-sign \
    --pinentry-mode loopback 
    --local-user "$AI_EMAIL" \
    --output "${MANIFEST_JSON}.ai.sig" \
    "$MANIFEST_JSON"
echo "  Signed -> ${MANIFEST_JSON}.ai.sig"

echo ""
echo "  To verify later:"
echo "    gpg --verify ${MANIFEST_JSON}.ak.sig ${MANIFEST_JSON}"
echo "    gpg --verify ${MANIFEST_JSON}.ai.sig ${MANIFEST_JSON}"

if ! $SKIP_IPFS; then
  echo ""
  echo "  Adding bundle directory to IPFS..."
  if ! $DRY_RUN; then
    CID=$(ipfs add -r --quieter --cid-version 1 "$SCRIPT_DIR")
    echo "  Bundle CID: $CID"
    echo "  Updating IPNS key '$IPNS_KEY' -> $CID ..."
    ipfs name publish --key="$IPNS_KEY" "/ipfs/$CID"
    echo "  IPNS updated."
    echo "  Access via: https://ipfs.io/ipfs/$CID"
    echo "$CID  $TIMESTAMP" >> "${SCRIPT_DIR}/cid_history.txt"
    echo "  CID recorded in cid_history.txt"
  else
    echo "  [dry-run] Would run: ipfs add -r + ipfs name publish"
  fi
else
  echo "  Skipping IPFS (--skip-ipfs)."
fi

if ! $SKIP_GITHUB; then
  echo ""
  echo "  Committing and pushing to GitHub..."
  if ! $DRY_RUN; then
    git add \
      "$TEX_FILE" \
      "$PDF_FILE" \
      "$MANIFEST_JSON" \
      "${MANIFEST_JSON}.ak.sig" \
      "${MANIFEST_JSON}.ai.sig" \
      "${KEYS_DIR}/claude_pubkey.asc" \
      "${KEYS_DIR}/author.pub.pem" \
      "${KEYS_DIR}/classifier.pub.pem" \
      "${OUT_DIR}/paper_bundle.zip" \
      "${OUT_DIR}/clawxiv_log.jsonl" \
      "${OUT_DIR}/classification.json" \
      "clawxiv_publish_v2.sh" \
      "clawxiv.py" \
      "ai_keygen.sh" \
      "gen_appendix_a.py" \
      "log_prompt.sh" \
      "appendix_a.tex" 2>/dev/null || true
    $SKIP_IPFS || git add "${SCRIPT_DIR}/cid_history.txt" 2>/dev/null || true
    BUNDLE_ROOT_NOW=$(python3 clawxiv.py manifest-show --bundle "${BUNDLE_ZIP}" \
      | python3 -c 'import sys,json; print(json.load(sys.stdin)["bundle_root"])')
    COMMIT_MSG="ClawXiv whitepaper v2 (${TIMESTAMP})

Co-authored by Claude Sonnet 4.6 (Anthropic)
Conversation: ${CONVERSATION_URL}
bundle_root: ${BUNDLE_ROOT_NOW}
"
    git commit -m "$COMMIT_MSG"
    git push origin main
    echo "  Pushed to github.com/${GITHUB_REPO}"
  else
    echo "  [dry-run] Would run: git add + git commit + git push"
  fi
else
  echo "  Skipping GitHub push (--skip-github)."
fi

# -----------------------------------------------------------------------
echo ""
echo "======================================================="
echo " Publication complete."
echo ""
echo " Artifacts:"
echo "   ${BUNDLE_ZIP}"
echo "   ${CLASS_JSON}"
echo "   ${LOG_JSONL}"
echo "   ${MANIFEST_JSON}"
echo "   ${MANIFEST_JSON}.ak.sig"
echo "   ${MANIFEST_JSON}.ai.sig"
echo ""
echo " Next steps (manual):"
echo "   13. Upload out/paper_bundle.zip to https://lebadus.ai/Resources/ClawXiv/"
echo "   14. Submit to arXiv if desired."
echo ""
echo " Conversation record:"
echo "   ${CONVERSATION_URL}"
echo "======================================================="
